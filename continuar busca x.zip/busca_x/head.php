<head>			
			<img src="Logo.png" height="40px" class="logo" >

			<nav>
				
				<a href="index.php">Inicio </a>| <a href="Importar_ERP.php">Importar ERP </a> | <a href="importar_XML.php"> Importar XML </a>

			</nav>

		</head>