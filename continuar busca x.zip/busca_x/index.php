<?php require 'software/conexao.php'; ?>
<html>
<head>
	<title>busca-X index</title>
	<link rel="stylesheet" type="text/css" href="css.css">
</head>
<body>

		<main>
				<?php


				include_once 'head.php';
				?>

				<section>


						<div>

							<small> <a href=""> Baixar .csv >> </small>
							<img src="baixar.png" height="20px;"> </a>

						</div>


					</div>
					
					<table align="center">

						<h2>Divergência</h2>

						<tr>
							<td> Código da Mercadoria</td>
							<td> Referência ERP</td>
							<td> Referência NFE</td>
							<td> Vinculo ERP</td>
							<td> Vinculo NFE</td>
							<td> Descrição</td>
							<td> Fabricante</td>
							

						</tr>

						<tr>
							<td> 12 </td>
							<td> 789621789</td>
							<td> 789621789</td>
							<td> 580</td>
							<td> 580</td>
							<td> SH UNILEVER</td>
							<td> HASKELL</td>

						</tr>
												

					</table>

					<div>

				</section>

				<?php

				include_once 'rodape.php';

				?>
		</main>

</body>
</html>