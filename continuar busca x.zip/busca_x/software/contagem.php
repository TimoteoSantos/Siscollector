<?php




require "conexao.php";

	
	//select
	$pasta = mysqli_query($conexao,  "SELECT COUNT(id_import_erp) FROM importar_erp ;");
	//conta
	$conta = $pasta->fetch_row();
	//recebe o valor
	$id2 = $conta;


echo $id2[0];
