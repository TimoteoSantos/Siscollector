<?php

session_start();
require "conexao.php";
		

	$sql = "TRUNCATE importar_erp";
	mysqli_query($conexao, $sql);

	/* destino dos arquivos configurados pelo usuario a proxima linha configura manualmente por aqui é so descomentar*/

	$destino = "/util/temp/erp.txt";

    //pega o destino
	//$destino = $linha["arquivo"]. '/produtos.txt'; // pega o caminho do banco e concatena com o nome do arquivo

	//mysqli_options($conexao, MYSQLI_OPT_LOCAL_INFILE, true);

	$sql = "LOAD DATA

	LOCAL INFILE '/util/erp.txt'

	REPLACE INTO TABLE importar_erp

	FIELDS TERMINATED BY ';'";
	
	$result = mysqli_query($conexao, $sql);

	//@unlink("$destino"); //apaga o arquivo
	
			//envia mensagem
		//$_SESSION['msg'] = "<div class='alert alert-success'>Verificar importação!</div>";
		header("Location: ../importar_erp.php");
