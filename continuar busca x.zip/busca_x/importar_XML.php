<?php require_once 'software/conexao.php'; ?>

<!DOCTYPE html>
<html>
<head>
	<title>busca-X index</title>
	<link rel="stylesheet" type="text/css" href="css.css">
</head>
<body>

		<main>
				<?php

				include_once 'head.php';
				?>

				<section>
										

						<h2>Importar XML</h2>

						<form action="software/importar_erp.php" class="formulario">
							
							<fieldset>
								
									<input type="submit" name="enviar" value="Subir" class="butao">

									<span class="alinhar_a_direita">
											
									<?php

									$pasta = mysqli_query($conexao,  "SELECT COUNT(id_import_erp) FROM importar_erp ;");
									$conta = $pasta->fetch_row();
									$id2 = $conta;

									?> 

									<span>Total Importado [ <?php echo $id2[0]; ?> ]

										Colocar o arquivo util/erp.txt com os dados

									</span>

								</span>

							</fieldset>

						</form>

						<p>
						<h2>Listar</h2>

						<table align="center">



						<tr>
							<td> Código </td> 
							<td> Referência </td> 
							<td> Vinculo </td> 
							<td> Descrição </td> 
							<td> CNPJ </td> 
						</tr>	
		<?php 
                     
        $result = "SELECT * FROM importar_erp  order by referencia_erp desc ";

        $resultado = mysqli_query($conexao, $result);

     	while($linha = mysqli_fetch_array($resultado)){
 
  		?>

							<tr>
							<td> <?= $linha['codigo_erp'] ?> </td> 
							<td> <?= $linha['referencia_erp'] ?> </td> 
							<td align="center"> <?= $linha['vinculo_erp'] ?> </td> 
							<td> <?= $linha['descricao_erp'] ?> </td> 
							<td> <?= $linha['cnpj'] ?> </td> 
						</tr>						


						<?php } ?>

					</table>

				</section>

				<?php

				include_once 'rodape.php';

				?>
		</main>

</body>
</html>